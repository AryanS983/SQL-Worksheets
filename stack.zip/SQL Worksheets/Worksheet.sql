CREATE TABLE Doctor (
SSN VARCHAR2(15) PRIMARY KEY,
FirstName VARCHAR2(50),
LastName VARCHAR2(50),
Specialty VARCHAR2(100),
YearsOfExperience NUMBER,
PhoneNum VARCHAR2(15)
);

desc Doctor;
